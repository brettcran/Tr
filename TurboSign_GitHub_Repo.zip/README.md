# TurboSign

TurboSign is a modern, mobile-friendly PDF and image annotation tool built with PDF.js and FastAPI.

## Features

- Upload and view multi-page PDFs or images
- Transparent, movable, resizable annotations (Text, Signature, Check, Circle)
- Signature drawing with memory for last 3 signatures
- Text formatting: font, size, bold, italic
- Flatten annotations and export as compressed PDF
- Mobile-compatible UI

## Project Structure

```
/frontend   - Deploy to Netlify
/backend    - Deploy to Render (FastAPI)
```

## Deploy Instructions

### Frontend (Netlify)

1. Upload contents of `/frontend` to Netlify
2. Done

### Backend (Render)

1. Create new **Web Service**
2. Point to `/backend` folder
3. Use **Python** environment
4. Set `Start Command`: `uvicorn main:app --host 0.0.0.0 --port 10000`
5. Enable CORS (already handled)

---

Built for TurboSign.app — simple, fast, reliable document annotation.
